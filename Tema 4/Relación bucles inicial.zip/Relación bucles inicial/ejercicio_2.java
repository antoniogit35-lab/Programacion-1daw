public class ejercicio_2 {
    static void main() {
        int suma = 0;
        for (int i=1; i<=100; i++)
        {
            suma = suma + i;
        }
        System.out.println("La suma es: " +suma);
    }
}
