//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    for (int i=1;i<=10; i++)
    {
        System.out.println("contador: " +i);
    }

    }

