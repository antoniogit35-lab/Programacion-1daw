public class ejercicio_4 {
    static void main() {
        for (int i=10; i>=0; i--){
            System.out.println(i);
        }
    }
}
