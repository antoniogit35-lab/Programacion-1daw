public class ejercicio_5 {
    static void main() {
        for (int i=1; i<=50; i++){
            if (i%5 == 0){
                System.out.println(i);
            }
        }
        for (int i=5; i<=50; i+=5){
            System.out.println(i);
        }
    }
}
