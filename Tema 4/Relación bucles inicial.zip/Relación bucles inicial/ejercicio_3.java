public class ejercicio_3 {
    static void main() {
        int suma = 0;
        for (int i =1; i<=20; i++){
            if (i%2 ==0){
                System.out.println(i);
            }

        }
        for(int i=2; i<=20; i+=2){
            System.out.println(i);
        }

    }
}
