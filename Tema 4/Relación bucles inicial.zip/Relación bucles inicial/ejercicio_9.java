public class ejercicio_9 {
    static void main() {
        int multiplos=0;
        int i;
        for (i =1; i<=100; i++){
            if(i %3 == 0){
                multiplos++;
            }
        }
        System.out.println(multiplos);
    }
}
