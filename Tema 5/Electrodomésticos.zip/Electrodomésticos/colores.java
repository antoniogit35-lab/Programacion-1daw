public enum colores {
    BLANCO, NEGRO, PLATEADO, ROJO, AZUL, GRIS
}
